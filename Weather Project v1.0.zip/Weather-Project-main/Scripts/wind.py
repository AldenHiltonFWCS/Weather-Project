def run(db):
    data = db.run()
    import plotly.graph_objects as go

    kv = {}
    for i in data:
        kv[float(i['windspeed'])] = float(i['winddir'])

    fig = go.Figure()
    fig.add_trace(go.Barpolar(
    r=[kv[wd] for wd in sorted(kv) if 14 <= wd <= 17],
    name='14-17 m/s',
    marker_color='rgb(93, 211, 174)'
    ))
    fig.add_trace(go.Barpolar(
        r=[kv[wd] for wd in sorted(kv) if 11 <= wd <= 14],
        name='11-14 m/s',
        marker_color='rgb(106,81,163)'
    ))
    fig.add_trace(go.Barpolar(
        r=[kv[wd] for wd in sorted(kv) if 8 <= wd <= 11],
        name='8-11 m/s',
        marker_color='rgb(158,154,200)'
    ))
    fig.add_trace(go.Barpolar(
        r=[kv[wd] for wd in sorted(kv) if 5 <= wd <= 8],
        name='5-8 m/s',
        marker_color='rgb(203,201,226)'
    ))

    fig.update_traces(text=['North', 'N-E', 'East', 'S-E', 'South', 'S-W', 'West', 'N-W'])
    fig.update_layout(
        title='Wind Speed Distribution in Eminence, Indiana',
        font_size=16,
        legend_font_size=16,
        polar_radialaxis_ticksuffix='%',
        polar_angularaxis_rotation=90,

    )
    fig.show()


try:
    import datacompiler
    run(datacompiler)
except:
    pass
