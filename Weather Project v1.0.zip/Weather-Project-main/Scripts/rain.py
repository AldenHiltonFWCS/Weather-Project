import plotly.graph_objects as go
import csv
def run():
    y = []
    kv = {}
    for i in range(1, 12):
        with open(f'data/Eminence{i}.csv', newline='') as f:
            reader = csv.DictReader(f)
            current = []
            for i in reader:
                current.append(float(i['precip']))
                # kv[float(i['windspeed'])] = float(i['winddir'])
            y.append(current)
    fig = go.Figure(data=go.Contour(z=[i for i in y], colorbar=dict(title='Millimeters (mm)', titleside='right'), contours=dict(showlabels=True)),
                    layout={'title': 'Eminence, Indiana Precipitation'})
    fig.show()

try:
    import datacompiler
    run()
except:
    pass