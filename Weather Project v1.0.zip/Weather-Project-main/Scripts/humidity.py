
def run(dc):
    import pandas as pd
    import plotly.express as px
    import numpy as np
    from datetime import datetime
    data = dc.run()
    datastuff = []
    xdata = []
    for i in data:  
        d = i["datetime"]
        h = i['humidity']
        xdata.append(d)
        datastuff.append(float(h))
    humid_dict = {'humidity': datastuff, 'date': xdata}

    fig = px.histogram(humid_dict, x='date', y='humidity', marginal='violin', title='Humidity in Eminence, IN', opacity=0.5)
    fig.show()

    
try:
    import datacompiler
    run(datacompiler)
except:
    pass

