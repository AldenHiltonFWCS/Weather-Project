import csv
def run():
    files = [1,2,3,4,5,6,7,8,9,10,11]
    frames = []
    for i in files:
        with open(f"data/Eminence{i}.csv", newline = '') as csvfile:
            reader = csv.reader(csvfile, delimiter=',', quotechar='|')
            for row in reader:
                if row[0] == "name":
                    continue
                frame = {
                    "name" : row[0],
                    "datetime" : row[1],
                    "tempmax" : row[2],
                    "tempmin" : row[3],
                    "temp" : row[4],
                    "feelslikemax" : row[5],
                    "feelslikemin" : row[6],
                    "feelslike" : row[7],
                    "dew" : row[8],
                    "humidity" : row[9],
                    "precip" : row[10],
                    "precipprob" : row[11],
                    "precipcover" : row[12],
                    "preciptype" : row[13],
                    "snow" : row[14],
                    "snowdepth" : row[15],
                    "windgust" : row[16],
                    "windspeed" : row[17],
                    "winddir" : row[18],
                    "sealevelpressure" : row[19],
                    "cloudcover" : row[20],
                    "visibility" : row[21],
                    "solarradiation" : row[22],
                    "solarenergy" : row[23],
                    "uvindex" : row[24],
                    "severerisk" : row[25],
                    "sunrise" : row[26],
                    "sunset" : row[27],
                    "moonphase" : row[28],
                    "conditions" : row[29],
                    "description" : row[30],
                    "icon" : row[31],
                    "stations" : row[32]
                }
                frames.append(frame)
    return frames
def showdata():
    for i in run():
        print(i["datetime"])
        for key, value in i.items():
            print(f"   {key}: {value}")