def run(database):
    data = database.run()
    from datetime import datetime
    from plotly import offline
    import plotly.graph_objects as go
    descriptions = []
    dates = []
    names = []
    for i in data:
        descriptions.append(i["description"])
        dates.append(i["datetime"])
        names.append(i["name"])
    totals = {}
    for i in descriptions:
        if i.strip() not in totals:
            totals[i.strip()] = 1
        else:
            totals[i.strip()] += 1
    totalthings = 0
    for k, v in totals.items():
        totalthings += v
    #print(f"Total Events: {totalthings}")
    #for k, v in totals.items():
    #    print(f"{k}: {((v/totalthings) * 10000) // 100}% ({v})")
    labels = []
    values = []
    for k, v in totals.items():
        labels.append(k)
        values.append(v)
    colors = ['blue', 'white', 'mediumturquoise', 'gray']
    fig = go.Figure(data=[go.Pie(labels=labels, values=values, 
                    title='Rates of Events in Eminence, IN.', titlefont_size=36)])
    fig.update_traces(hoverinfo= 'label+percent', textinfo='value', textfont_size=24,
                    marker=dict(colors = colors, line=dict(color='#000000', width=3)))
    fig.show()

try:
    import datacompiler
    run(datacompiler)
except:
    pass