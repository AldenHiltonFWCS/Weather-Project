def run(database):
  import tkinter as tk
  data = database.run()
  root = tk.Tk() 
  root.title("Weather Predictor")
  root.resizable(False, False)
  root.grid()
  def quit():
    root.destroy()
  def predict():
    #theday = day.get()
    #themonth = month.get()
    #theyear = year.get()
    #timestamp = f"{themonth}-{theday}-{theyear}"
    timestamp = "2022-07-15"
    year = int(timestamp[0:4])
    month = int(timestamp[5:7])
    day = int(timestamp[8:10])

    values = {}
    for i in data:
      for k, v in i.items():
        try:
          values[k].append(v)
        except:
          values[k] = [v]
    
    averages = {}
    for k, v in values.items():
      try:
        avg = 0
        for i in v:
          avg += float(i)
        avg = ((1000 * (avg / len(v))) // 100) / 10
        averages[k] = avg
      except:
        pass
    text = f"""
-= Primary Focuses =-

Temperature: {averages["temp"]}°F
Temp. Feels: {averages["feelslike"]}°F
Chance of Rain: {averages["precip"] * 100}%
Humidity: {averages["humidity"]}%
Wind Speed: {averages["windspeed"]} MPH
Wind Direction: {averages["winddir"]}°


-= Other Details =-

Temp. High: {averages["tempmax"]}°F
Temp. High Feels: {averages["feelslikemax"]}°F
Temp. Low: {averages["tempmin"]}°F
Temp. Low Feels: {averages["feelslikemin"]}°F
Cloud Coverage: {averages["cloudcover"]}%
Rain Coverage: {averages["precipcover"]}%
Dew: {averages["dew"]}%
"""
    root2 = tk.Tk() 
    root2.geometry("250x400")
    root2.title(timestamp)
    root2.resizable(False, False)

    root2.grid()
    tk.Label(root2, text = f"{timestamp} Prediction", padx = 10, pady = 10).grid(columnspan=1,row=0)
    tk.Label(root2, text = ' ').grid(columnspan=1,row=1)
    tk.Label(root2, text = text, padx = 10, pady = 10).grid(columnspan=1,row=2)
  tk.Label(root, text = "Predict Eminence Indiana's Weather").grid(columnspan=3,row=0)
  #tk.Label(root, text = "Enter a date as |01| |02| |2022|").grid(columnspan=3,row=1)
  tk.Label(root, text = "Date is locked as 2022-07-15").grid(columnspan=3,row=1)
  tk.Label(root, text = "MONTH").grid(column=0,row=2)
  tk.Label(root, text = "DAY").grid(column=1,row=2)
  tk.Label(root, text = "YEAR").grid(column=2,row=2)
  month = tk.StringVar
  tk.Entry(root, textvariable= month).grid(column=0,row=3)
  day = tk.StringVar
  tk.Entry(root, textvariable= day).grid(column=1,row=3)
  year = tk.StringVar
  tk.Entry(root, textvariable= year).grid(column=2,row=3)

  info = tk.Label(root, text = " ").grid(columnspan=2,row=5)

  tk.Button(root, text = "Grab a prediction", command = lambda: predict()).grid(columnspan=3,row=4)
  tk.Button(root, text = "Quit Program", command = lambda: quit()).grid(columnspan=3,row=6)
  
  
  root.mainloop()

  
try:
    import datacompiler
    run(datacompiler)
except:
    pass