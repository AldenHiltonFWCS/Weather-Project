def run(database):
    import csv
    import plotly.graph_objects as go
    import numpy as np
    from datetime import datetime
    data = database.run()
    humidity = []
    for i in range(1, 12):
        current = []
        with open(f'data/Eminence{i}.csv') as f:
            reader = csv.DictReader(f)
            for j in reader:
                current.append(j['humidity'])
            humidity.append(current)

    july21, july22, july23, july24, july25 = [], [], [], [], []
    for i, j, k, l, m in zip(humidity[0], humidity[1], humidity[2], humidity[3], humidity[4]):
        july21.append(i)
        july22.append(j)
        july23.append(k)
        july24.append(l)
        july25.append(m)

    fig = go.Figure(go.Heatmap(
        x=[21, 22, 23, 24, 25],
        y=[2011, 2012, 2013, 2014, 2015, 2016, 2017, 2018, 2019, 2020, 2021],
        z=[july21, july22, july23, july24, july25]
    ),
    layout=dict(title='Humidity in Eminence, IN (2011-2021)', xaxis=dict(title='July 21 - 25', dtick=1), yaxis=dict(title='2011 - 2021', dtick=1))
    )
    fig.show()

'''import datacompiler
run(datacompiler)
try:
    pass
except:
    pass'''