# BRIAN ALDEN
def run(dc):
    import plotly.express as px
    import matplotlib.pyplot as plt
    from datetime import datetime
    data = dc.run() 
    datastuff = []
    xdata = ['']
    
    for i in data:
        xdata.append(i["datetime"])
        datastuff.append([float(i["tempmin"]), float(i["tempmax"])])
        #datastuff.append(frame)

    fig, ax = plt.subplots()
    ax.set_title("Temperatures in Eminence, IN", fontsize=24)
    ax.set_xlabel("Date", fontsize=10)
    ax.set_ylabel("F°", fontsize=20)    
    plt.style.use('seaborn')

    ax.boxplot(datastuff)
    plt.xticks(range(0, len(xdata)), xdata, rotation='vertical')
    plt.show()

try:
    import datacompiler
    run(datacompiler)
except:
    pass