import Scripts.datacompiler as database
import tkinter as tk
try:
    import Scripts.humidity as humid
except:
    print("Error on humid")
try:
    import Scripts.prediction as predict
except:
    print("Error on predict")
try:
    import Scripts.wind as wind
except:
    print("Error on wind")
try:
    import Scripts.temperature as temp
except:
    print("Error on temp")
try:
    import Scripts.rain as rain
except:
    print("Error on rain")
try:
    import Scripts.events as events
except:
    print("Error on events")


'''
XANDER - Events
ALDEN - Rain, Humidity
EH - Wind
BRIAN - Temperatures
EVERYONE - Predictions
'''


root = tk.Tk() 
root.title("P-Test")
root.resizable(False, False)
root.grid()


tk.Label(root, text = "Weather Analysis for Eminence Indiana").grid(column=0,row=0)

tk.Label(root, text = "2011-2022").grid(column=0,row=1)
tk.Label(root, text = "\nClick an option below to view data").grid(column=0,row=2)

tk.Button(root, text = "July 21-25 Prediction", command = lambda: predict.run()).grid(column=0,row=3)
tk.Button(root, text = "Wind Data", command = lambda: wind.run(database)).grid(column=0,row=4)
tk.Button(root, text = "Humidity", command = lambda: humid.run(database)).grid(column=0,row=5)
tk.Button(root, text = "Precipitation", command = lambda: rain.run(database)).grid(column=0,row=6)
tk.Button(root, text = "Temperatures", command = lambda: temp.run(database)).grid(column=0,row=7)
tk.Button(root, text = "Weather Events", command = lambda: events.run(database)).grid(column=0,row=8)
tk.Button(root, text = "Quit Program", command = lambda: root.destroy()).grid(column=0,row=9)

tk.Label(root, text = "\nXander, Brian, Eh, Alden").grid(column=0,row=9)

root.mainloop()
