def run(database):
    data = database.run()
    from datetime import datetime
    import plotly.express as px
    descriptions = []
    dates = []
    names = []

    for i in data:
        descriptions.append(i["description"])
        dates.append(i["datetime"])
        names.append(i["name"])

    df = px.data.gapminder().query()
    

import datacompiler
run(datacompiler)