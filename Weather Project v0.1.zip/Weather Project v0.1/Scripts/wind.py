def run(da
    import plotly.express as px
    import datacompiler
    print(data)
    winddir, windspeed = [], []
    for i in data:
        winddir.append(i['winddir'])
        windspeed.append(i['windspeed'])
    fig = px.bar_polar({'direction': winddir, 'speed': windspeed},
                   theta="direction",
                   color="speed", template="plotly_dark",
                   color_discrete_sequence=px.colors.sequential.Plasma_r, title='Eminence, Indiana')
    fig.show()
    fig.show()
    print("Running this function will pull data into Main")

#run()