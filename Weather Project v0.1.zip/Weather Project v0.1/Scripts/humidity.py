def run():
    print("Running this function will pull data into Main")
