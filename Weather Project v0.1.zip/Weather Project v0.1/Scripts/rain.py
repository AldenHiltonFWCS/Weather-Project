import sys
import pathlib
sys.path.insert(1, pathlib.Path(__file__).parent.absolute())

def run():
    import datacompiler as database
    import plotly.express as px
    data = database.run()
    fig = px.scatter(x=[1, 2, 3], y=[1, 2, 3])
    fig.show()